package Principal;

public class Animal implements Cloneable {
    private int daño;
    private int vidaAnimal;
    private int precio;
    private int nivelIndividual;
    private int nivelGrupal;
    private int experiencia;
    private int conteoUsoDeAnimal;
    private int indiceDeMascota;
    private int tier;
    private int elegirEquipo;
    private String tipoEspecie;
    private String tipoBioma;
    private String nombreDeMascota;
    private boolean activarHabilidad;
    
    //CONSTRUCTOR INICIAL
    public Animal(int daño, int vidaAnimal, int precio, int nivelIndividual, int nivelGrupal, int experiencia, int conteoUsoDeAnimal, int indiceDeMascota, int tier, String tipoEspecie, String tipoBioma, String nombreDeMascota){
        this.daño = daño;
        this.vidaAnimal = vidaAnimal;
        this.precio = precio;
        this.nivelIndividual = nivelIndividual;
        this.nivelGrupal = nivelGrupal;
        this.experiencia = experiencia;
        this.conteoUsoDeAnimal = conteoUsoDeAnimal;
        this.indiceDeMascota = indiceDeMascota;
        this.tier = tier;
        this.tipoEspecie = tipoEspecie;
        this.tipoBioma = tipoBioma;
        this.nombreDeMascota = nombreDeMascota;
        this.activarHabilidad = false;
        
    }

    public Animal() {
    }

    
    public Object clonarse () throws CloneNotSupportedException{
        
        return super.clone();
    }
    

    //SOBRE ATAQUES
    public void atacar(Animal animalAtacado) {
        animalAtacado.recibirAtaque(daño);
    }
    
    public void recibirAtaque(int dañoRecibido){
        vidaAnimal = vidaAnimal - dañoRecibido;
        
    }
    
    //SOBRE MEJORAS
    public void recibirMejorasDeComida(Comida comidaRecibida){
        daño = daño + comidaRecibida.getMejoraDeDaño();
        vidaAnimal = vidaAnimal + comidaRecibida.getMejoraDeVida();
    }
    
    public void recibirMejoraDeTerreno(){
        
    }
    
    public void recibirMejorasDeEspecie(){
        
    }
    
    public void fusionarMascota(){
        
    }
    
    public void serComprada(){
        
    }
     public void serVendido(){
        setActivarHabilidad(false);
    }
            
        
    
    
    //PARA LA HABILIDAD
    
    public Animal[] usarHabilidad(Jugador jugador){
        return jugador.getEquipo();
    }
    
    public int elegirEquipoParaHabilidad(){
        return this.elegirEquipo;
    }
    
    public void iniciarBatalla (){
        setActivarHabilidad(false);
    }
        
            
    
    public boolean evaluarSignosVitales (){

        return vidaAnimal <= 0;
    }
    
    public void subirNivelIndividual(int ronda){
        setActivarHabilidad(false);
        nivelIndividual++;
    }
    
    public void subirNivelGrupal(){
        setActivarHabilidad(false);
        if(nivelGrupal < 4){
            nivelGrupal++;
            vidaAnimal++;
            daño++;
        }
    }
    
    public void aumentarExperiencia(){
        experiencia++;
    }


    
    //||||||||||||||||||||||||||||
    //          GETTER'S 
    //||||||||||||||||||||||||||||

    public int getDaño() {
        return daño;
    }

    public int getVidaAnimal() {
        return vidaAnimal;
    }

    public int getPrecio() {
        return precio;
    }

    public int getNivelIndividual() {
        return nivelIndividual;
    }

    public int getNivelGrupal() {
        return nivelGrupal;
    }

    public int getExperiencia() {
        return experiencia;
    }

    public int getConteoUsoDeAnimal() {
        return conteoUsoDeAnimal;
    }

    public int getIndiceDeMascota() {
        return indiceDeMascota;
    }

    public String getTipoDeMascota() {
        return tipoEspecie;
    }

    public String getNombreDeMascota() {
        return nombreDeMascota;
    }

    public boolean getActivarHabilidad() {
        return activarHabilidad;
    }
    
    
    
    
    //|||||||||||||||||||||||||||||
    //      SETTERS'S
    //|||||||||||||||||||||||||||||

    public void setNombre(String nombre){
        nombreDeMascota = nombre;
    }
    
    public void setDaño(int daño) {
        this.daño = daño;
    }

    public void setVidaAnimal(int vidaAnimal) {
        this.vidaAnimal = vidaAnimal;
    }

    public void setNivelIndividual(int nivelIndividual) {
        this.nivelIndividual = nivelIndividual;
    }

    public void setNivelGrupal(int nivelGrupal) {
        this.nivelGrupal = nivelGrupal;
    }

    public void setExperiencia(int experiencia) {
        this.experiencia = experiencia;
    }

    public void setConteoUsoDeAnimal(int conteoUsoDeAnimal) {
        this.conteoUsoDeAnimal = conteoUsoDeAnimal;
    }

    public void setIndiceDeMascota(int indiceDeMascota) {
        this.indiceDeMascota = indiceDeMascota;
    }

    public void setTipoDeMascota(String tipoBioma) {
        this.tipoBioma = tipoBioma;
    }

    public void setActivarHabilidad(boolean activarHabilidad) {
        this.activarHabilidad = activarHabilidad;
    }
    
    public void setElegirEquipoParaHabilidad(int indice){
       this.elegirEquipo = indice;
    }
}


