package Principal;


import java.util.Scanner;


public class Principal {
    public static void main (String[] arg){
        Juego motorJuegoArena = new Juego();
        Juego motorJuegoCreativo = new Juego();
        Juego motorJuegoVs = new Juego();
        Imprimir imprimir = new Imprimir();
        boolean salirDelJuego = false;
        Scanner sc = new Scanner(System.in);
        String seleccionarOpcion;
        while(!salirDelJuego){
            
            
            imprimir.menuPrincipal();
            seleccionarOpcion = sc.nextLine();
            
            if("arena".equalsIgnoreCase(seleccionarOpcion)){
                
                imprimir.modoArenaInicio();
                boolean salir1 = false;
                    while(!salir1){
                        Jugador jugadores[] = new Jugador[2];
                        Jugador respaldo[] = new Jugador[2];
                        jugadores[0] = new Jugador();
                        jugadores[1] = new Bot();
           
                        jugadores[0] = motorJuegoArena.tienda();
                        jugadores[1] = motorJuegoArena.getBot();
           
                    try {
                        respaldo [0]= (Jugador) jugadores[0].clonarse();
                        respaldo [1]= (Jugador) jugadores[1].clonarse();
                    } catch (CloneNotSupportedException ex) {
                        System.out.println("ERROR AL RESPALDAR");
                    }
                        motorJuegoArena.batalla(respaldo); 
                        
                        if(motorJuegoArena.salirVerificar() == true){
                        salir1 = true;
                        }
                    }
                    motorJuegoArena.ReportesFinales();
            }
            else{
                
                
                
                
                
                
                if("vs".equalsIgnoreCase(seleccionarOpcion)){
                    imprimir.modoVsInicio();
                    Texto archivoTexto = new Texto();
                    
                    boolean salir2 = false;
                    while(!salir2){
                        Jugador jugadores[] = new Jugador[2];
                        Jugador respaldo[] = new Jugador[2];
                        jugadores[0] = new Jugador();
                        jugadores[1] = new Jugador();
           
                        jugadores[0] = motorJuegoVs.tienda();
                        archivoTexto.enviarEquipo(jugadores[0], "versus");
                        try{
                            
                        Animal[] animalesRecibidos = archivoTexto.leerEquipo("creativo");
                        jugadores[1].setEquipo(animalesRecibidos);
                        imprimir.equipoDelJugador(jugadores[1]);
                        
                        }catch(Exception e){System.out.println("error");}
                    try {
                        respaldo [0]= (Jugador) jugadores[0].clonarse();
                        respaldo [1]= (Jugador) jugadores[1].clonarse();
                    } catch (CloneNotSupportedException ex) {
                        System.out.println("ERROR AL RESPALDAR");
                    }
                        motorJuegoVs.batalla(respaldo); 
                        
                        if(motorJuegoVs.salirVerificar() == true){
                        salir2 = true;
                        }
                    }
                    
                    sc.nextLine();
                }
                else{
                    
                    
                    
                    
                    
                    
                    
                    if("creativo".equalsIgnoreCase(seleccionarOpcion)){
                        
                        imprimir.modoCreativo();
                       Texto archivoTexto = new Texto();
                    
                    boolean salir3 = false;
                    while(!salir3){
                        
                        Jugador jugadores[] = new Jugador[2];
                        Jugador respaldo[] = new Jugador[2];
                        jugadores[0] = new Jugador();
                        jugadores[0].setOro(10000);
                        jugadores[1] = new Bot();
                        motorJuegoCreativo.getJugador()[0].setOro(10000);
                        
                        jugadores[0] = motorJuegoCreativo.tienda();
                        
                        archivoTexto.enviarEquipo(jugadores[0], "creativo");
           
                        salir3 = true;
                        
                    }
                    }
                    else{
                        
                        
                        
                        
                        
                        
                        
                        if("salir".equalsIgnoreCase(seleccionarOpcion)){
                            imprimir.mensajeDeSalida();
                            salirDelJuego = true;
                            break;
                        }
                        else
                            System.out.println(" ");
                            System.out.println("Opccion invalida");
                            System.out.println("Intenta de nuevo");
                            
                        }
                    }
                }
            }
            
            
            
            
                        
            
            
            
            
            
            
        }
        
        
        
        
        
        
        
        
        
        
        
        
    }

