package Principal;

import java.util.Scanner;


public class Tienda {
    private Animal mascotaEnVenta[] = new Animal[10];
    private Animal mascotasAleatorias[] = new Animal[5];
    Animal ola = new Animal();
    MascotaNueva mascotas = new MascotaNueva();
    Imprimir imprimir = new Imprimir();
    
    public Animal vender(Animal[] animalesDisponibles,String nombreDeMascota){
        int indice = animalesDisponibles.length;
        //Animal clon = null;
                                                       
        for (int i = 0; i < indice; i++) {
                                                        
            try{                                                    
                if((animalesDisponibles[i].getNombreDeMascota()).equalsIgnoreCase(nombreDeMascota)){
                    
                    return animalesDisponibles[i];                   
                    
                }
                else{
                    
                }          
            }catch(Exception e){
            }                                       
        }   
        return null;
        
    }
    
    
    public Animal[] eliminarDeTienda(Animal[] disponibles, Animal vendido){
        int indice = disponibles.length;
        for (int i = 0; i < indice; i++) {
            try{
                if(!(disponibles[i].getNombreDeMascota()).equalsIgnoreCase(vendido.getNombreDeMascota())){
                } else {
                    disponibles[i] = null;
                    break;
                }
            
            }catch(Exception e){
                
            }
        }
        return disponibles;
        
    }
    
    public Jugador eliminarDeEquipo (Jugador equipoParaBorrar, String nombreMascota){
        for (int i = 0; i < equipoParaBorrar.getEquipo().length; i++) {
            try{
                    if((equipoParaBorrar.getEquipo()[i].getNombreDeMascota()).equalsIgnoreCase(nombreMascota)){
                        equipoParaBorrar.venderAnimal((equipoParaBorrar.getEquipo()[i]), i);
                        equipoParaBorrar.setOro((equipoParaBorrar.getOro()) + 2);
                    }
                    else{
                        System.out.println("No se pudo realizar la venta");
                    }
            }catch(Exception e){
                
            }
        }
        
        
        
        return equipoParaBorrar;
        
    }
    
    public int cobrarMascota(int oro){        //este metodo probablemente sea inecesario y en vender se cobre jaja
        return oro;
    }
    
    
    public Animal[] ofrecerMascotasAleatorias(int tier, int ronda){
        int noDeMascotas;
        int rangoDeTier = 0;
        noDeMascotas = switch (ronda) {
            case 1, 2, 3 -> 3;
            case 4, 5, 6 -> 4;
            case 7 -> 5;
            default -> 3;
        };
        
        rangoDeTier = switch (tier) {
            case 1 -> 8;
            case 2 -> 15;
            case 3 -> 26;
            case 4 -> 34;
            case 5 -> 42;
            case 6 -> 52;
            case 7 -> 43;
            default -> 8;
        };
        for (int i = 0; i < noDeMascotas; i++) {
            int random = (int)(Math.random() * rangoDeTier);
            
            mascotasAleatorias[i] = mascotas.getMascotaElegida(random);
        }
        return mascotasAleatorias;
    }
    
    public Animal[] fusionarAnimales(Animal[] mascota, int indice1, int indice2){
        if((mascota[indice1].getNombreDeMascota().equalsIgnoreCase(mascota[indice2].getNombreDeMascota())) && (mascota[indice1].getNivelGrupal() == mascota[indice2].getNivelGrupal())){
            mascota[indice1].subirNivelGrupal();
            mascota[indice2] = null;
        }
        return mascota;
        
    }
    
    public Animal[] ordenarEquipo(Animal[] equipo){
        boolean out = false;
        Animal cambio[] = new Animal[5]; 
        while(!out){
                imprimir.margen();
                System.out.println("EQUIPO ORIGINAL");
                imprimir.imprimirEnLinea(equipo);
                System.out.println(" ");
                System.out.println("EQUIPO MODIFICADO");
                imprimir.imprimirEnLinea(cambio);
                System.out.println(" ");
            Scanner cs = new Scanner(System.in);
            try{
            System.out.println("Opciones: [Nombre de mascota que quieras cambiar]       [TERMINAR]");
            String mascota = cs.nextLine();
            
            if(!"terminar".equals(mascota)){
            
            System.out.println("Numero de Casilla a la cual se movera");
            int no = cs.nextInt();
            no--;
            for (int i = 0; i < equipo.length; i++) {
                try{
                if((equipo[i].getNombreDeMascota()).equalsIgnoreCase(mascota)){
                cambio[no] = equipo[i];
                equipo = eliminarDeTienda(equipo, cambio[no]);
                break;
            }
                }catch(Exception e){
                    
                }
                
            }
            cs.nextLine();
            }else{
                int conteo = 0;
                if("terminar".equalsIgnoreCase(mascota)){
                for (int i = 0; i < equipo.length; i++) {
                    try{
                    equipo[i].evaluarSignosVitales();
                    }catch(Exception e){
                        conteo++;
                    }
                }
                if(conteo == equipo.length){
                    out=true;
                }
                else{
                    System.out.println("Debes terminar de ordenar el equipo");
                }
            }
                
            }
            
            }catch(Exception e){
                System.out.println("Valores incorrectos");
            }
            finally{
            
    
            //cs.nextLine();
            
            //System.out.println("[ENTER] o [TERMINAR]");
           // int conteo = 0;
           // String lectura = cs.nextLine();
        /*    if("terminar".equalsIgnoreCase(lectura)){
                for (int i = 0; i < equipo.length; i++) {
                    try{
                    equipo[i].evaluarSignosVitales();
                    }catch(Exception e){
                        conteo++;
                    }
                }
                if(conteo == equipo.length){
                    out=true;
                }
                else{
                    System.out.println("Demes terminar de ordenar el equipo");
                }
            } */
        }
        
            imprimir.margen();
            imprimir.espacioEnBlanco();
            
        }
        return cambio;
        
    }
}

    