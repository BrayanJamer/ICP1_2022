package Principal;
import Animales.*;
import Habilidades.*;
//AQUI SE INICIALIZAN LOS ANIMALES Y DESDE AQUI SE PUEDEN DISTRIBUIR A DONDE SEAN NECESARIOS MEDIANTE METODOS

public class MascotaNueva {

    private Animal mascota[] = new Animal[55];
    private CompañerismoHormiga habilidadHormiga;

    
    
    public MascotaNueva(){
        for (int i = 0; i < mascota.length; i++) {
            mascota[i] = new Animal();
        }
        
        int indice = 0;
        mascota[indice] = new Hormiga(2,1,3,1,1,0,0,indice,1,"Insecto","Terrestre","Hormiga");//HORMIGA
        indice++;
        mascota[indice] = new Pescado(2,3,3,1,1,0,0,indice,1," ","Acuatico","Pescado");//PESCADO
        indice++;
        mascota[indice] = new Mosquito (2,2,3,1,1,0,0,indice,1," ","Acuatico","Mosquito");//MOSQUITO
        indice++;
        mascota[indice] = new Grillo (1,2,3,1,1,0,0,indice,1,"Insecto"," ","Grillo");//MOSQUITO
        indice++;
        mascota[indice] = new Castor(2,2,3,1,1,0,0,indice,1,"Terrestre","Acuatico","Castor");//Grillo [1/2]
        indice++;
        mascota[indice] = new Animal(2,1,3,1,1,0,0,indice,1,"Domestico","Mamifero","Caballo");//Castor [2/2]
        indice++;
        mascota[indice] = new Animal(1,2,3,1,1,0,0,indice,1," ","Mamifero","Nutria");//Caballo [2/1]
        indice++;
        mascota[indice] = new Animal(2,3,3,1,1,0,0,indice,1," ","Insecto","Escarabajo");//Nutria [1/2]
        indice++;
        mascota[indice] = new Animal(3,3,3,1,1,0,0,indice,2,"Terrestre","Acuatico","Sapo");//Escarabajo [2/3]
        indice++;
        mascota[indice] = new Animal(2,3,3,1,1,0,0,indice,2," ","Volador","Dodo");//Sapo [3/3]
        indice++;
        mascota[indice] = new Animal(3,5,3,1,1,0,0,indice,2,"Mamifero","Terrestre","Elefante");//Dodo [2/3]
        indice++;
        mascota[indice] = new Animal(3,2,3,1,1,0,0,indice,2,"Solitario","Terrestre","Puerco Espin");//Elefante: [3/5]
        indice++;
        mascota[indice] = new Animal(2,5,3,1,1,0,0,indice,2,"Solitario","Terrestre","Pavo Real");//voreal [2/5  ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(4,5,3,1,1,0,0,indice,2,"Solitario","Terrestre","Rata");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(5,2,3,1,1,0,0,indice,2,"Solitario","Terrestre","Zorro");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(2,2,3,1,1,0,0,indice,2,"Solitario","Terrestre","Araña");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(2,5,3,1,1,0,0,indice,2,"Solitario","Terrestre","Camello");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(5,4,3,1,1,0,0,indice,2,"Solitario","Terrestre","Mapache");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(2,5,3,1,1,0,0,indice,2,"Solitario","Terrestre","Jirafa");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(1,2,3,1,1,0,0,indice,2,"Solitario","Terrestre","Tortuga");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(2,2,3,1,1,0,0,indice,2,"Solitario","Terrestre","Caracol");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(2,2,3,1,1,0,0,indice,2,"Solitario","Terrestre","Oveja");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(3,2,3,1,1,0,0,indice,2,"Solitario","Terrestre","Conejo");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(3,4,3,1,1,0,0,indice,2,"Solitario","Terrestre","Lobo");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(1,4,3,1,1,0,0,indice,2,"Solitario","Terrestre","Buey");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(3,2,3,1,1,0,0,indice,2,"Solitario","Terrestre","Canguro");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(5,3,3,1,1,0,0,indice,2,"Solitario","Terrestre","Buho");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(1,1,3,1,1,0,0,indice,2,"Solitario","Terrestre","Venado");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(5,3,3,1,1,0,0,indice,2,"Solitario","Terrestre","Loro");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(4,7,3,1,1,0,0,indice,2,"Solitario","Terrestre","Hipopótamo");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(4,6,3,1,1,0,0,indice,2,"Solitario","Terrestre","Delfín");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(3,7,3,1,1,0,0,indice,2,"Solitario","Terrestre","Puma");//Puerco Espin [3/2]     ME QUEDE AQUI, PROBAR CON LO QUE YA ESTA 
        indice++;
        mascota[indice] = new Animal(3,8,3,1,1,0,0,indice,2,"Solitario","Terrestre","Ballena");//
        indice++;
        mascota[indice] = new Animal(2,5,3,1,1,0,0,indice,2,"Solitario","Terrestre","Ardilla");//
        indice++;
        mascota[indice] = new Animal(3,6,3,1,1,0,0,indice,2,"Solitario","Terrestre","Llama");//
        indice++;
        mascota[indice] = new Animal(3,8,3,1,1,0,0,indice,2,"Solitario","Terrestre","Foca");//
        indice++;
        mascota[indice] = new Animal(7,4,3,1,1,0,0,indice,2,"Solitario","Terrestre","Jaguar");//
        indice++;
        mascota[indice] = new Animal(1,1,3,1,1,0,0,indice,2,"Solitario","Terrestre","Escorpion");//
        indice++;
        mascota[indice] = new Animal(5,8,3,1,1,0,0,indice,2,"Solitario","Terrestre","Rinoceronte");//
        indice++;
        mascota[indice] = new Animal(1,2,3,1,1,0,0,indice,2,"Solitario","Terrestre","Mono");//
        indice++;
        mascota[indice] = new Animal(8,4,3,1,1,0,0,indice,2,"Solitario","Terrestre","Cocodrilo");//
        indice++;
        mascota[indice] = new Animal(4,6,3,1,1,0,0,indice,2,"Solitario","Terrestre","Vaca");//
    }

    public Animal getMascotaElegida(int indice) {
        //mascota[indice].setIndiceDeMascota((mascota[indice].getIndiceDeMascota()) + 1);
        return mascota[indice];
    }

    public Animal[] getMascota() {
        return mascota;
    }
    
}
