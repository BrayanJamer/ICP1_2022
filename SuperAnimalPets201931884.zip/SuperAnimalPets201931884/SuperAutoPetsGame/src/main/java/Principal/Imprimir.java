package Principal;


public class Imprimir {
    
    public void imprimirTodo(Animal[] mascota){
            System.out.println("MASCOTAS EN VENTA");
        for (int i = 0; i < mascota.length; i++) {
            try{
            System.out.println(" ");
            System.out.println("Nombre de mascota: "+mascota[i].getNombreDeMascota());
            System.out.println("Vida de la mascota: "+mascota[i].getVidaAnimal());
            System.out.println("Daño de la mascota: "+mascota[i].getDaño());
            }catch(Exception e){
                //System.out.println("Casilla No."+i+" disponible");
            }
        }
            
          
         
        
    }
    
    public void menuPrincipal(){
        System.out.println("SUPER AUTO PETS");
        System.out.println("1. Modo arena:      [arena]");
        System.out.println("2. Modo versus:     [vs]");
        System.out.println("3. Modo Creativo:   [creativo]");
        System.out.println("4. Salir            [salir]");
    }
    
    public void modoArenaInicio(){
        System.out.println(" ");
        System.out.println("¡¡MODO ARENA!!");
    }
    
     public void modoVsInicio(){
        System.out.println(" ");
        System.out.println("¡¡MODO VERSUS!!");
    }
    
     public void modoCreativo(){
        System.out.println(" ");
        System.out.println("¡¡MODO CREATIVO!!");
    }
     
     public void mensajeDeSalida(){
        System.out.println("GRACIAS POR JUGAR");
        System.out.println("    ADIOS");
    }
    
     public void imprimirEnLinea(Animal[] mascota){
       
        for (int i = 0; i < mascota.length; i++) {
            int indiceMostrar = i + 1;
            try{
            System.out.println(" ");
            System.out.print("Casilla No."+indiceMostrar+": "+mascota[i].getNombreDeMascota());
            System.out.print(" Vida: "+mascota[i].getVidaAnimal());
            System.out.print(" Daño: "+mascota[i].getDaño());
            }catch(Exception e){
                System.out.print("Casilla No."+indiceMostrar+" disponible");
            }
            
        }
            
          System.out.println(" ");
         
        
    }
     
    public void instruccionesTienda(){
        System.out.println("Puedes comprar mascotas y ordenarlas en las casillas disponibles");
        System.out.println("Tambien puedes vender las mascotas que tengas o hacer roll las ofertas de la tienda");
    }
    
    public void datosDelJugador(Jugador jugador){
            System.out.println("DATOS DEL JUGADOR:  ");
            System.out.print("Oro: "+jugador.getOro());
            System.out.print("    Vida: "+ jugador.getVida());
            System.out.print("    Victorias: "+jugador.getVictorias());
            System.out.println(" ");
    }
    
    
    public void equipoDelJugador(Jugador jugador){
        int j = 0;
        Animal leerEquipo[] = jugador.getEquipo();
            
        while(j < 5){
            int aumento = 1;
                try{
                            
                    leerEquipo[j].evaluarSignosVitales();
                    System.out.print("Casilla NO." + (j+aumento) + " ocupada por: ");
                    System.out.print(leerEquipo[j].getNombreDeMascota());
                    System.out.print(" Daño: "+leerEquipo[j].getDaño());
                    System.out.println(" Vida: "+leerEquipo[j].getVidaAnimal());
                        }
                catch(Exception e){
                    System.out.println("Casilla NO." + (j+aumento) + " disponible");
                            
                        }
                finally{
                    j++; 
                        }
                        
                    }
    }
    
    public void equipoInvertido(Jugador jugador){
        int j = 4;
        Animal leerEquipo[] = jugador.getEquipo();
        while(j > (-1)){
                        int aumento = 1;
                        try{
                            leerEquipo[j].evaluarSignosVitales();
                            System.out.print("Casilla NO." + (j+aumento) + " ocupada por: ");
                            System.out.print(leerEquipo[j].getNombreDeMascota());
                            System.out.print(" Daño: "+leerEquipo[j].getDaño());
                            System.out.println(" Vida: "+leerEquipo[j].getVidaAnimal());
                        }
                        catch(Exception e){
                            System.out.println("Casilla NO." + (j+aumento) + " disponible");
                            
                        }
                        finally{
                            
                        }
                        j--;
                    }
    }
    
    public void margen(){
        System.out.println("///////////////////////////////////////////////////////////////////////////////");
    }
    
    public void espacioEnBlanco(){
        System.out.println(" ");
        System.out.println(" ");
    }
    
    
    
    
    
    }
