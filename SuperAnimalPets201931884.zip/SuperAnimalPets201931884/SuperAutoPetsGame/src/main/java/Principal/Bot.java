
package Principal;

public class Bot extends Jugador{
    private Animal[] equipoBot = new Animal[5];
    private Animal[] mascotasDisponibles = new Animal[7];
    
    public void equipoBot(int tier, int ronda){
        Tienda tienda = new Tienda();
     
        mascotasDisponibles = tienda.ofrecerMascotasAleatorias(tier, ronda);
        int i = 0;
       while(super.getOro()>2){
           
           try{
            int indice = mascotasDisponibles.length;
            int random = (int)(Math.random() * indice);
            Animal randomMascota = tienda.vender(mascotasDisponibles, mascotasDisponibles[random].getNombreDeMascota());
            
            if(randomMascota.elegirEquipoParaHabilidad() == 1){
                randomMascota.setElegirEquipoParaHabilidad(0);
            }else{
                if(randomMascota.elegirEquipoParaHabilidad() == 0){
                    randomMascota.setElegirEquipoParaHabilidad(1);
                }
            }
            
            equipoBot[i] = (Animal) randomMascota.clonarse();
            //equipoBot[i] = tienda.vender(mascotasDisponibles, mascotasDisponibles[random].getNombreDeMascota());
            super.setOro((super.getOro())-3);
            i++;
           }catch(Exception e){
               
           }
       }
       super.setEquipo(equipoBot);
        
    }
}
