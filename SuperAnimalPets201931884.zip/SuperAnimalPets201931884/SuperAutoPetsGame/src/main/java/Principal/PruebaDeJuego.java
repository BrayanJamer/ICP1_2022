package Principal;


//import java.util.Scanner;

public class PruebaDeJuego {
     //private static final Juego iniciarJuego = new Juego();
/*
    public static void main(String[] arg) throws CloneNotSupportedException {
         Juego iniciarJuego = new Juego();
         
            boolean salirDelJuego = false;
       while(!salirDelJuego){
           Jugador jugadores[] = new Jugador[2];
           Jugador respaldo[] = new Jugador[2];
           jugadores[0] = new Jugador();
           jugadores[1] = new Jugador();
           
           //jugadores = iniciarJuego.tienda();
           
           respaldo [0]= (Jugador) jugadores[0].clonarse();
           respaldo [1]= (Jugador) jugadores[1].clonarse();
            iniciarJuego.batalla(respaldo);
            
           
       }
       iniciarJuego.setSalirMaster(false);
       //salirDelJuego = iniciarJuego.isSalirMaster();
       
    }

*/
}