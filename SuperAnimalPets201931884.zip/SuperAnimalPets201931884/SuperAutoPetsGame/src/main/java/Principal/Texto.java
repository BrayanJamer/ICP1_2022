
package Principal;
import java.io.*;
import java.nio.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Texto {
    
    public void enviarEquipo(Jugador jugador, String nombreArchivo){
        Animal[] equipo = jugador.getEquipo();
        FileWriter archivoEnviar;
        try {
            archivoEnviar = new FileWriter(nombreArchivo+".txt",false);
        } catch (IOException ex) {
        }
        
        for (int i = 0; i < equipo.length; i++) {
            
            try{
            String datosEnviar = (equipo[i].getNombreDeMascota()+", " + equipo[i].getNivelGrupal()+"\n");
        try {           
            archivoEnviar = new FileWriter(nombreArchivo+".txt",true);
            archivoEnviar.write(datosEnviar);
            archivoEnviar.close();
            
        } catch (IOException ex) { }
            }catch(Exception e){ }
        
        
    }
    }
    
    public Animal[] leerEquipo(String nombreArchivo1){
       Jugador equipoLeido = new Jugador();
       Animal equipoNuevo[] = new Animal[5];
        try {
            FileReader archivoRecibir = new FileReader(nombreArchivo1+".txt");
            BufferedReader leer = new BufferedReader(archivoRecibir);
            for (int i = 0; i < 4; i++) {
                try{
                    String lectura = leer.readLine();
                    System.out.println(lectura);
                    equipoNuevo[i] = buscarAnimal(lectura);
                    //System.out.println(equipoNuevo[i].getNombreDeMascota()+"uuuUUUUU");
                    
                }catch(IOException e){
                        }
                
            }
        } catch (FileNotFoundException ex) {
        }finally{
            //equipoLeido.setEquipo(equipoNuevo);
        }
        
        return equipoNuevo;
        }
    
    
    
    public Animal buscarAnimal(String buscar){
        MascotaNueva mascotas = new MascotaNueva();
        Animal mascotasDisponibles[] = mascotas.getMascota();
        
        for (int i = 0; i < mascotasDisponibles.length; i++) {
            String cadenaBuscada = (mascotasDisponibles[i].getNombreDeMascota()+", " + mascotasDisponibles[i].getNivelGrupal());
            //System.out.println("aaaaaaaa"+cadenaBuscada);
            if((buscar).equalsIgnoreCase(cadenaBuscada)){
                return mascotasDisponibles[i];
                
            }
            
        }
        
        return null;
        
    }
}
    

