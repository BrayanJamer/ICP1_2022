package Principal;

public class Jugador implements Cloneable{
    private String nombreDelJugador;
    private int victorias;
    private int rondasJugadas;
    private int oro;
    private int vida;
    private Animal equipo[] = new Animal[5];
    private boolean bando;
    //private ;
    
    public Jugador(){
        oro = 10;
        vida = 10;
        victorias = 0;
        rondasJugadas = 0;
        /*for (int i = 0; i < jugador[0].getEquipo().length; i++) {
            jugador[0].setEquipo(null);
        }
        for (int i = 0; i < jugador[1].getEquipo().length; i++) {
            jugador[1].setEquipo(null);
        }*/
        //equipo = null;
    }
    
    public Object clonarse () throws CloneNotSupportedException{
        
        return super.clone();
    }
    
    public void comprarAnimales(Animal mascotaComprada, int indice) throws CloneNotSupportedException{
        if(oro >= 3){
            Animal comprado = (Animal) mascotaComprada.clonarse();
            equipo[indice] = comprado;
            oro = oro - equipo[indice].getPrecio();
        }else{
            System.out.println("Oro insuficiente");
        }
    }
    
    public void venderAnimal(Animal vendido, int indice){
        this.equipo[indice] = null;
    }
    
    public void comprarComida(){
        
    }
    
    public void ordenarEquipo(){
               
    }
    
    
    //REPORTES, METODOS PARA LLEVAR EL CONTEO DE REPORTES
    public void conteoDeAnimalMasUsado(Animal conteoDeUso){
        int conteo = conteoDeUso.getConteoUsoDeAnimal();
        conteoDeUso.setConteoUsoDeAnimal(conteo++);
    }
    
    public void desempeñoConMascotas(){
        
    }
    
    public void oroGastado(){
        
    }

    public Animal[] getEquipo() {
        return equipo;
    }

    public String getNombreDelJugador() {
        return nombreDelJugador;
    }

    public int getVictorias() {
        return victorias;
    }

    public int getRondasJugadas() {
        return rondasJugadas;
    }

    public int getOro() {
        return oro;
    }

    public int getVida() {
        return vida;
    }

    public boolean getBando() {
        return bando;
    }

    public void setNombreDelJugador(String nombreDelJugador) {
        this.nombreDelJugador = nombreDelJugador;
    }

    public void setVictorias(int victorias) {
        this.victorias = victorias;
    }

    public void setRondasJugadas(int rondasJugadas) {
        this.rondasJugadas = rondasJugadas;
    }

    public void setOro(int oro) {
        this.oro = oro;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public void setBando(boolean bando) {
        this.bando = bando;
    }
    
    public void setEquipo(Animal[] equipo) {
        this.equipo = equipo;
    }
    
    
    
}