package Principal;

import java.util.Scanner;

public class Juego {
    private String etapaDeLaPelea;
    private Jugador jugador[] = new Jugador[2];   //EL JUGADOR 0 ES EL USUARIO Y EL 1 ES EL BOOT
    private Animal mascotasEnTienda[] = new Animal[10];
    private Tienda tiendaEntreBatallas = new Tienda();
    private Scanner sc = new Scanner(System.in);
    private int ronda;
    private int tier;
    private Bot bot = new Bot();
    private boolean salirMaster;
    private Imprimir imprimir = new Imprimir();

    public Juego(){
        jugador[0] = new Jugador();
        jugador[1] = new Jugador();
        this.salirMaster = false;
        this.ronda = 0;
        this.tier = 0;
        this.bot = new Bot();
        
    }
    
    public Jugador tienda(){
        Imprimir mostrar = new Imprimir();
        boolean salir1 = false;
        boolean salir2 = false;
        boolean finDelJuego = false;
        String leer;
        ronda++;
        tier++;
        jugador[0].setOro(10);
        jugador[1].setOro(10);
        
        //BUCLE GENERAL PARA LAS RONDAS
        //while (!finDelJuego){
            //BUCLE ESPECIAL PARA EL MENU DE LA TIENDA//
            
            bot.equipoBot(tier, ronda);
            mascotasEnTienda = tiendaEntreBatallas.ofrecerMascotasAleatorias(tier, ronda);
            jugador[1] = bot;
            
            
    while(!salir1){
                
                
              int j=0;
              Animal leerEquipo[] = jugador[0].getEquipo();
              mostrar.margen(); 
              System.out.println("TIENDA");
              //etapaDeLaPelea = "  TIENDA  ";
              mostrar.datosDelJugador(jugador[0]);
              mostrar.equipoDelJugador(jugador[0]);
              mostrar.imprimirTodo(mascotasEnTienda);
              System.out.println("Opciones:   [ROLL]   [COMPRAR]   [VENDER]   [ORDENAR]   [BATALLA]");
                leer = sc.nextLine();

                if("comprar".equalsIgnoreCase(leer)){
                    try{
                        System.out.println("Ingresa el nombre de la mascota que quieres comprar");
                        String leerNombreMascota = sc.nextLine();
                        System.out.println("Ingresa el numero de la casilla donde vas a colocar la mascota");
                        int noMascota = sc.nextInt(); 
                        int indice = noMascota -1;
                        if(jugador[0].getEquipo()[indice] == null){
                            
                            jugador[0].comprarAnimales(tiendaEntreBatallas.vender(mascotasEnTienda,leerNombreMascota), indice);
                            jugador[0].getEquipo()[indice].serComprada();
                            jugador[jugador[0].getEquipo()[indice].elegirEquipoParaHabilidad()].setEquipo(jugador[0].getEquipo()[indice].usarHabilidad( jugador[jugador[0].getEquipo()[indice].elegirEquipoParaHabilidad()]));
                            mascotasEnTienda = tiendaEntreBatallas.eliminarDeTienda(mascotasEnTienda, jugador[0].getEquipo()[indice]);
                            
                        }else{
                            System.out.println("La casilla No."+( noMascota) +" ya esta ocupada");
                        }
                    }catch(Exception e){}
                    sc.nextLine();
                    

                }
                else{
                    if("vender".equalsIgnoreCase(leer)){
                        System.out.println("Ingresa el nombre de la mascota que quieres vender");
                        String leerNombreMascota = sc.nextLine();
                        jugador[0] = tiendaEntreBatallas.eliminarDeEquipo(jugador[0], leerNombreMascota);
                        
                        
                        
                    }else{
                    if("roll".equalsIgnoreCase(leer)){
                        
                        if(jugador[0].getOro() > 0){
                           jugador[0].setOro(jugador[0].getOro()-1);
                        mascotasEnTienda = tiendaEntreBatallas.ofrecerMascotasAleatorias(tier, ronda);
                        //mostrar.imprimirTodo(mascotasEnTienda);
                        }else{
                            System.out.println("Oro insuficiente");
                        }

                    }
                    else{
                        if("ordenar".equalsIgnoreCase(leer)){
                            jugador[0].setEquipo(tiendaEntreBatallas.ordenarEquipo(leerEquipo));
                        }
                        else{
                            if("batalla".equalsIgnoreCase(leer)){
                                salir1 = true;
                                setSalirMaster(true);
                                break;
                            }
                        }
                    } 
                }
            }
                mostrar.margen();
                mostrar.espacioEnBlanco();
            }
            
            for (int i = 0; i < 2; i++) {
                if(jugador[i].getVida()<=0){
                jugador[i].setVida(jugador[i].getVictorias() + 1);
                
            }
            }
         
            
            ronda++;
            
    //}
        return jugador[0];
    
    }

        
    public void batalla(Jugador[] combatiente){
        Imprimir imprimirBatalla = new Imprimir();
        Jugador jugadorRespaldo[] = new Jugador[combatiente.length];
       
        int indice = 0;
        jugadorRespaldo [0] = combatiente[0];
        jugadorRespaldo [1] = combatiente[1];
        jugadorRespaldo[0].setEquipo(ordenarParaSiguienteBatalla(jugadorRespaldo[0].getEquipo()));
        jugadorRespaldo[1].setEquipo(ordenarParaSiguienteBatalla(jugadorRespaldo[1].getEquipo()));
        
        
        imprimirBatalla.equipoInvertido(jugadorRespaldo[0]);
        System.out.println("VS");
        imprimirBatalla.equipoDelJugador(jugadorRespaldo[1]);
sc.nextLine();


        for (int i = 0; i < jugadorRespaldo[0].getEquipo().length; i++) {
            try{
            jugador[0].getEquipo()[i].iniciarBatalla();
           jugador[jugador[0].getEquipo()[i].elegirEquipoParaHabilidad()].setEquipo(jugador[0].getEquipo()[i].usarHabilidad( jugador[jugador[0].getEquipo()[i].elegirEquipoParaHabilidad()]));
            }catch(Exception e){
                
            }
        }
        for (int i = 0; i < jugadorRespaldo[1].getEquipo().length; i++) {
            try{
            jugador[1].getEquipo()[i].iniciarBatalla();
           jugador[jugador[1].getEquipo()[i].elegirEquipoParaHabilidad()].setEquipo(jugador[1].getEquipo()[i].usarHabilidad( jugador[jugador[1].getEquipo()[i].elegirEquipoParaHabilidad()]));
            }catch(Exception e){
                
            }
            
        }
        imprimirBatalla.equipoInvertido(jugadorRespaldo[0]);
        System.out.println("Resultado de Habilidades");
        imprimirBatalla.equipoDelJugador(jugadorRespaldo[1]);
        
        
sc.nextLine();
        
        boolean mantenerBatalla = false;
        while(!mantenerBatalla){
            
        if((jugadorRespaldo[0].getEquipo()[indice] != null) && (jugadorRespaldo[1].getEquipo()[indice] != null)){
            
            jugadorRespaldo[0].setEquipo(eliminarAnimalPerdedor((jugadorRespaldo[0].getEquipo()) , (jugadorRespaldo[0].getEquipo()[0]) , (jugadorRespaldo[0].getEquipo()[0].evaluarSignosVitales())));
            jugadorRespaldo[1].setEquipo(eliminarAnimalPerdedor((jugadorRespaldo[1].getEquipo()) , (jugadorRespaldo[1].getEquipo()[0]) , (jugadorRespaldo[1].getEquipo()[0].evaluarSignosVitales())));
            
            
            jugadorRespaldo[0].setEquipo(ordenarParaSiguienteBatalla(jugadorRespaldo[0].getEquipo()));
            jugadorRespaldo[1].setEquipo(ordenarParaSiguienteBatalla(jugadorRespaldo[1].getEquipo()));
                
            
imprimirBatalla.margen();
                jugadorRespaldo[0].getEquipo()[indice].atacar(jugadorRespaldo[1].getEquipo()[indice]);
                //System.out.println("    VS");
                jugadorRespaldo[1].getEquipo()[indice].atacar(jugadorRespaldo[0].getEquipo()[indice]);
                
                imprimirBatalla.equipoInvertido(jugadorRespaldo[0]);
                System.out.println("    RESULTADO VS");
                imprimirBatalla.equipoDelJugador(jugadorRespaldo[1]);
sc.nextLine();

                try{
                jugador[jugador[0].getEquipo()[0].elegirEquipoParaHabilidad()].setEquipo(jugador[0].getEquipo()[0].usarHabilidad(jugador[jugador[0].getEquipo()[0].elegirEquipoParaHabilidad()]));
                jugador[jugador[1].getEquipo()[0].elegirEquipoParaHabilidad()].setEquipo(jugador[1].getEquipo()[0].usarHabilidad(jugador[jugador[1].getEquipo()[0].elegirEquipoParaHabilidad()]));
                }catch(Exception e){    
                }

                jugadorRespaldo[0].setEquipo(eliminarAnimalPerdedor((jugadorRespaldo[0].getEquipo()) , (jugadorRespaldo[0].getEquipo()[0]) , (jugadorRespaldo[0].getEquipo()[0].evaluarSignosVitales())));
                jugadorRespaldo[1].setEquipo(eliminarAnimalPerdedor((jugadorRespaldo[1].getEquipo()) , (jugadorRespaldo[1].getEquipo()[0]) , (jugadorRespaldo[1].getEquipo()[0].evaluarSignosVitales())));

              
                jugadorRespaldo[0].setEquipo(ordenarParaSiguienteBatalla(jugadorRespaldo[0].getEquipo()));
                jugadorRespaldo[1].setEquipo(ordenarParaSiguienteBatalla(jugadorRespaldo[1].getEquipo()));
                
                imprimirBatalla.equipoInvertido(jugadorRespaldo[0]);
                System.out.println("    VS");
                imprimirBatalla.equipoDelJugador(jugadorRespaldo[1]);
sc.nextLine();
imprimirBatalla.margen();
            
        }
        else{
            if(jugadorRespaldo[0].getEquipo()[indice] != null && jugadorRespaldo[1].getEquipo()[indice] == null){
                System.out.println("BATALLA GANADA");
                jugador[0].setVictorias((jugador[0].getVictorias()) + 1);
                mantenerBatalla = false;
                break;
            }else
                if(jugadorRespaldo[1].getEquipo()[indice] != null && jugadorRespaldo[0].getEquipo()[indice] == null){
                    System.out.println("BATALLA PERDIDA");
                    jugador[0].setVida((jugador[0].getVida()) -1);
                    mantenerBatalla = false;
                    break;
                }
                else{
                    System.out.println("¡¡¡EMPATE!!!");
                    mantenerBatalla = false;
                    break;
                }
        }
    }
        
    }


    public Animal[] eliminarAnimalPerdedor(Animal[] equipoEnJuego,Animal animalEliminado,boolean confirmar){
        if(confirmar == true){
            Tienda usarTienda = new Tienda();
            equipoEnJuego = usarTienda.eliminarDeTienda(equipoEnJuego, animalEliminado);
        }else{
            System.out.println("____________________________________________________");
        }
        return equipoEnJuego;
        
    }


    public Animal[] ordenarParaSiguienteBatalla(Animal[] equipoEnBatalla){
        Animal equipoListo[] = new Animal[equipoEnBatalla.length];
        int contador = 0;
        for (int i = 0; i < equipoEnBatalla.length; i++) {
            try{
            if(equipoEnBatalla[i] != null){
                equipoListo[contador] = equipoEnBatalla[i];
                contador++;
            }
        }catch(Exception e){
            
        }
           
        }
        return equipoListo;
        
    }
    
    public Jugador[] habilidadDeMascotas(Jugador[] jugadorr){
        for (int i = 0; i < jugadorr[0].getEquipo().length; i++) {
            int indiceAtacar = jugadorr[0].getEquipo()[i].elegirEquipoParaHabilidad();
            Animal animalQueAtaca = jugador[0].getEquipo()[i];
            jugadorr[indiceAtacar].setEquipo(animalQueAtaca.usarHabilidad(jugadorr[indiceAtacar]));
        }
        
        return jugadorr;
    }

    
    
    
    public boolean salirVerificar() {
        salirMaster = ronda > 10;
        return salirMaster;
    }
    
    public void ReportesFinales(){
        
    }

    public void setSalirMaster(boolean salirMaster) {
        this.salirMaster = salirMaster;
    }
    
    public Animal secuenciaHabilidad(Jugador jugador){
        
        return null;
}

    public Jugador[] getJugador() {
        return jugador;
    }

    public int getRonda() {
        return ronda;
    }

    public int getTier() {
        return tier;
    }
    
    public Jugador getBot(){
        bot.equipoBot(tier, ronda);
        return bot;
    }
    
    
}

