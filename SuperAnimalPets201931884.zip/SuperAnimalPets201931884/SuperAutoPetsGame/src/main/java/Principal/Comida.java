package Principal;


public class Comida {
    private int mejoraDeDaño;
    private int mejoraDeVida;
    
    public void mejorarMascota(){
       
    }
    
    public int serComprada(){
        
        return 0;
        
    }

    public int getMejoraDeDaño() {
        return mejoraDeDaño;
    }

    public int getMejoraDeVida() {
        return mejoraDeVida;
    }
    
}