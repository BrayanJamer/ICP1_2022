

package Habilidades;
import Principal.Animal;
import Principal.Jugador;



public class Habilidad {
    private int nivel;   
    private String habilidad;
    
    public void usarHabilidad(Animal equipoDelJugador,String estadoDeBatalla){
        
    }
   
    
    public boolean decidirUsoDeHabilidad(String estadoDeBatalla, boolean estarVivo){
        
        return false;
        
    }
}