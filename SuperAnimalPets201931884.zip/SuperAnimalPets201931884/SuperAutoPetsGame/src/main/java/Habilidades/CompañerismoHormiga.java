
package Habilidades;
import Principal.Animal;

public class CompañerismoHormiga extends Habilidad{
    

    public Animal[] usarHabilidad(Animal[] equipoJugador, String estadoDeBatalla){
        if("inicio".equalsIgnoreCase(estadoDeBatalla)){
        int cantidadDeMascotas = equipoJugador.length;
        int random = (int)(Math.random() * cantidadDeMascotas);
        int vida = equipoJugador[random].getVidaAnimal();
        int daño = equipoJugador[random].getDaño();
        equipoJugador[random].setVidaAnimal(vida + 2);
        equipoJugador[random].setDaño(daño + 2);
        }
        
        
        
        
        return equipoJugador;
    }
    
 
}
