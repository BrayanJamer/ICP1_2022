
package Habilidades;
import Principal.Animal;

public class PowerUpPescado {
    
    public Animal[] mejorarEquipo(Animal[] equipoAliado){
        int i = 0;
        for (Animal animal : equipoAliado) {
            int vida = equipoAliado[i].getVidaAnimal();
            int daño = equipoAliado[i].getDaño();
            equipoAliado[i].setVidaAnimal(vida + 2);
            equipoAliado[i].setDaño(daño + 2);
            
        }
        return equipoAliado;
        
    }
}
