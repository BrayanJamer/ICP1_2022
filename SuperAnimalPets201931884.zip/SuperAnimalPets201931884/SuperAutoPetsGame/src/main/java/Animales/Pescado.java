
package Animales;

import Habilidades.Habilidad;
import Principal.Animal;
import Principal.Jugador;

public class Pescado extends Animal{

    public Pescado(int daño, int vidaAnimal, int precio, int nivelIndividual, int nivelGrupal, int experiencia, int conteoUsoDeAnimal, int indiceDeMascota, int tier, String tipoEspecie, String tipoBioma, String nombreDeMascota ) {
        super(daño, vidaAnimal, precio, nivelIndividual, nivelGrupal, experiencia, conteoUsoDeAnimal, indiceDeMascota, tier, tipoEspecie, tipoBioma, nombreDeMascota);
        super.setElegirEquipoParaHabilidad(0);
    }
    
    
    
    @Override
    public Animal[] usarHabilidad(Jugador jugador){
        Animal equipo[] = jugador.getEquipo();
        int aumento = 0;
        aumento = switch (super.getNivelGrupal()) {
            case 1 -> 1;
            case 2 -> 2;
            case 3 -> 3;
            default -> 1;
        };
        if(getActivarHabilidad() == true){
            System.out.println("Powe Up");
            System.out.println("mejora a todo el equipo en " + aumento + " de daño y " + aumento+ " de vida");
            for (int i = 1; i < equipo.length; i++) {
                
                try{
                equipo[i].setVidaAnimal(equipo[i].getVidaAnimal() + aumento);
                equipo[i].setDaño(equipo[i].getDaño() + aumento);
                }catch(Exception e){
                    
                }
                
            }
        }
        setActivarHabilidad(false);
        
        return equipo;
        
    }
    
    
    @Override
    public void subirNivelGrupal(){
        super.subirNivelGrupal();
        setActivarHabilidad(true);
        
    }
}
