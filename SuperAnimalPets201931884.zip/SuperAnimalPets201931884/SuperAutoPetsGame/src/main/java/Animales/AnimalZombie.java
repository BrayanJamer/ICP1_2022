
package Animales;

import Principal.Animal;

public class AnimalZombie extends Animal{
    
    public AnimalZombie(int daño, int vida, String nombre){
        super.setNombre(nombre);
        super.setDaño(daño);
        super.setVidaAnimal(vida);
    }
    
}
