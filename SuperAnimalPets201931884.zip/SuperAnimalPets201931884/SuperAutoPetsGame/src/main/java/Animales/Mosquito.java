
package Animales;

import Principal.Animal;
import Principal.Jugador;
import java.util.Random;

public class Mosquito extends Animal {

    public Mosquito(int daño, int vidaAnimal, int precio, int nivelIndividual, int nivelGrupal, int experiencia, int conteoUsoDeAnimal, int indiceDeMascota, int tier, String tipoEspecie, String tipoBioma, String nombreDeMascota) {
        super(daño, vidaAnimal, precio, nivelIndividual, nivelGrupal, experiencia, conteoUsoDeAnimal, indiceDeMascota, tier, tipoEspecie, tipoBioma, nombreDeMascota);
        super.setElegirEquipoParaHabilidad(1);
    }
    
    
 @Override
 public void iniciarBatalla(){
        super.setActivarHabilidad(true);
        //super.setElegirEquipoParaHabilidad(1);
    }
    
 @Override
    public Animal[] usarHabilidad(Jugador jugador){
        Animal equipo[] = jugador.getEquipo();
        int cantAnimales = jugador.getEquipo().length;
        int enemigosAtacados = 0;
        int contador = 0;
        int contador2 = 0;
        if(super.getActivarHabilidad() == true){
            
            switch(super.getNivelGrupal()){
                case 1:
                    enemigosAtacados = 1;
                    break;
                case 2:
                    enemigosAtacados = 2;
                    break;
                case 3:
                    enemigosAtacados = 3;
                    break;
                default:
                    enemigosAtacados = 1;
                    break;
            }
            System.out.println("Mosquito hace 1 de daño a "+enemigosAtacados+" enemigo/s Al iniciar la partida");
                while(contador < enemigosAtacados){
                try{
                int random = (int)(Math.random() * cantAnimales);
                int rand = new Random(System.nanoTime()).nextInt(cantAnimales);
                    //System.out.println(random+"    "+rand);
                equipo[rand].setVidaAnimal((equipo[rand].getVidaAnimal()) - 1);
                    System.out.println("Enemigo atacado: "+equipo[rand].getNombreDeMascota());
                contador++;
                }catch(Exception e){
                    contador2++;
                    if(contador2 >10){
                        contador = 20;
                    }
                }
                }
        }
        super.setActivarHabilidad(false);
        return equipo;
        
    }
}
