
package Animales;

import Principal.Animal;
import Principal.Jugador;

public class Castor extends Animal{

    public Castor(int daño, int vidaAnimal, int precio, int nivelIndividual, int nivelGrupal, int experiencia, int conteoUsoDeAnimal, int indiceDeMascota, int tier, String tipoEspecie, String tipoBioma, String nombreDeMascota) {
        super(daño, vidaAnimal, precio, nivelIndividual, nivelGrupal, experiencia, conteoUsoDeAnimal, indiceDeMascota, tier, tipoEspecie, tipoBioma, nombreDeMascota);
        super.setElegirEquipoParaHabilidad(0);
    }
    
    @Override
    public void serVendido(){
        super.setActivarHabilidad(true);
    }

    @Override
    public Animal[] usarHabilidad(Jugador jugador){
        Animal equipo[] = jugador.getEquipo();
        int mejora = 0;
        int contador = 0;
        int contador2 = 0;
        while(contador < 2){
                switch(super.getNivelGrupal()){
                    case 1:
                        mejora = 1;
                    break;
                    case 2:
                        mejora = 2;
                    break;
                    case 3:
                        mejora = 3;
                    break;
                    default:
                        mejora = 1;
                }
                System.out.println("Da a 2 aliados "+mejora+" de vida extra");
        if(super.getActivarHabilidad() == true){
           
            
                try{
               int random = (int)(Math.random() * jugador.getEquipo().length);
               equipo[random].setVidaAnimal(equipo[random].getVidaAnimal() + mejora);
               contador++;
               
                }catch(Exception e){
                    contador2++;
                    if(contador2 > 20){
                        contador = 10;
                        break;
                    }
                }finally{
                    contador2++;
                    if(contador2 > 20){
                        contador = 10;
                        break;
                    }
                }
            }else{
            break;
        }
        }
        super.setActivarHabilidad(false);
        return equipo;
        
    }
}
