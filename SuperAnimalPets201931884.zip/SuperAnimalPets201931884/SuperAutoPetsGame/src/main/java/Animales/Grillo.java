
package Animales;

import Principal.Animal;
import Principal.Jugador;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Grillo extends Animal {

    public Grillo(int daño, int vidaAnimal, int precio, int nivelIndividual, int nivelGrupal, int experiencia, int conteoUsoDeAnimal, int indiceDeMascota, int tier, String tipoEspecie, String tipoBioma, String nombreDeMascota) {
        super(daño, vidaAnimal, precio, nivelIndividual, nivelGrupal, experiencia, conteoUsoDeAnimal, indiceDeMascota, tier, tipoEspecie, tipoBioma, nombreDeMascota);
        super.setElegirEquipoParaHabilidad(0);
    }
    
    @Override
    public boolean evaluarSignosVitales(){
        if(super.evaluarSignosVitales() == true){
        setActivarHabilidad(true);
        
        }
        return super.evaluarSignosVitales();
        
    }
    
    @Override
    public void iniciarBatalla(){
        super.setActivarHabilidad(false);
    }
    
    
    @Override
        public Animal[] usarHabilidad(Jugador jugador){
            Animal equipo[] = jugador.getEquipo();
            if(getActivarHabilidad() == true){
                int estadisticas = 0;
                switch(super.getNivelGrupal()){
                    case 1:
                        estadisticas = 1;
                        break;
                    case 2:
                        estadisticas = 2;
                        break;
                    case 3:
                        estadisticas = 3;
                        break;
                }
                Animal zombie = new AnimalZombie(estadisticas,estadisticas, "Grillo zombie");
                try {
                    Animal clon = (Animal)zombie.clonarse();
                    equipo[0] = clon;
                } catch (CloneNotSupportedException ex) {
                    Logger.getLogger(Grillo.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            super.setActivarHabilidad(false);
        return equipo;
    }
}
