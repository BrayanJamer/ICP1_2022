
package Animales;
import Habilidades.Habilidad;
import Principal.Animal;
import Principal.Jugador;
public class Hormiga extends Animal{

    public Hormiga(int daño, int vidaAnimal, int precio, int nivelIndividual, int nivelGrupal, int experiencia, int conteoUsoDeAnimal, int indiceDeMascota, int tier, String tipoEspecie, String tipoBioma, String nombreDeMascota) {
        super(daño, vidaAnimal, precio, nivelIndividual, nivelGrupal, experiencia, conteoUsoDeAnimal, indiceDeMascota, tier, tipoEspecie, tipoBioma, nombreDeMascota);
        super.setElegirEquipoParaHabilidad(0);
    }
    
    
    @Override
  public boolean evaluarSignosVitales (){
      if(super.evaluarSignosVitales() == true){
        setActivarHabilidad(true);
        
        }
        return super.evaluarSignosVitales();
    }
    
    @Override
    public Animal[] usarHabilidad(Jugador jugador){
        boolean out = false;
        Animal equipoJugador[] = jugador.getEquipo();
        int mejoraDeVida = 0;
        int mejoraDeDaño = 0;
        int contador = 0;
    while(!out){
        try{
        if(getActivarHabilidad() == true){
        
        int cantidadAnimales = jugador.getEquipo().length;
        
        int random = (int)(Math.random() * cantidadAnimales);
        int nivel = super.getNivelGrupal();
        
        switch(nivel){
            case 1 -> {
                mejoraDeVida=1;
                mejoraDeDaño=2;
            }
                
            case 2 -> {
                mejoraDeVida=2;
                mejoraDeDaño=4;
            }
            case 3 -> {
                mejoraDeVida=3;
                mejoraDeDaño=6;
            }
                
            default -> {
                mejoraDeVida=1;
                mejoraDeDaño=2;
            }
                
        }
      
        equipoJugador[random].setVidaAnimal(equipoJugador[random].getVidaAnimal() + mejoraDeVida);
        equipoJugador[random].setDaño(equipoJugador[random].getDaño() + mejoraDeDaño);
            System.out.println("Mascota mejorada: " +equipoJugador[random].getNombreDeMascota() + " en " + mejoraDeVida +" de vida y " + mejoraDeDaño+" de daño");
        }
        out = true;
        break;
        }catch(Exception e){
            contador++;
            if (contador > 10){
                out = true;
            }
        }
        
        }
        setActivarHabilidad(true);
        return equipoJugador;
        
    }
    
}
